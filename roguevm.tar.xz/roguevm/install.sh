ip link add link enp0s3 name spf0 type macvtap mode bridge
ip link set spf0 up

LD_PRELOAD=$(pwd)/shim.so ./qemu-system-x86_64 -kernel /boot/vmlinuz-$(uname -r) -initrd ./initramfs.linux_amd64.cpio -net nic,model=virtio,macaddr=$(cat /sys/class/net/spf0/address) -net tap,fd=3 3<>/dev/tap$(cat /sys/class/net/spf0/ifindex) -nographic -append "console=ttyS0"
