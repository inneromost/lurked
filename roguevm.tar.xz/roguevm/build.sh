#!/bin/bash

u-root -uinitcmd="/bin/sh -c 'ip link set eth0 up && ip addr add 192.168.0.113/24 dev eth0 && ip route add default via 192.168.0.1 dev eth0 && /bin/slv'" -files ../slv-qemu:/bin/slv ./cmds/core/{init,ip,dhclient,gosh}

